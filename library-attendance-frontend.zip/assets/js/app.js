/* Frontend SPA using localStorage
   - Data stored in localStorage keys: books, students, issues, attendance
   - This is a demo: no backend. Use in browser only.
*/
(function(){
  // utils
  const qs = s => document.querySelector(s);
  const qsa = s => Array.from(document.querySelectorAll(s));
  const uid = ()=> Date.now().toString(36) + Math.random().toString(36).slice(2,6);

  // storage helpers
  const load = (k)=> JSON.parse(localStorage.getItem(k) || '[]');
  const save = (k,v)=> localStorage.setItem(k, JSON.stringify(v));

  // initial demo data if empty
  if(!localStorage.getItem('books')){
    save('books', [
      {id: uid(), title:'Programming in C', author:'Dennis Ritchie', isbn:'ISBN001', copies:3, available:3},
      {id: uid(), title:'Database Systems', author:'Elmasri', isbn:'ISBN002', copies:2, available:2}
    ]);
  }
  if(!localStorage.getItem('students')){
    save('students', [
      {id: uid(), roll:'BCA001', name:'Aman', class:'BCA-1', phone:''},
      {id: uid(), roll:'BCA002', name:'Riya', class:'BCA-1', phone:''}
    ]);
  }
  if(!localStorage.getItem('issues')) save('issues', []);
  if(!localStorage.getItem('attendance')) save('attendance', []); // array of {student_id,date,status}

  // elements
  const view = qs('#view');
  const templates = {};
  qsa('template').forEach(t=> templates[t.id]=t);

  // auth simple (any email)
  const isSigned = ()=> !!localStorage.getItem('session');
  const signIn = (email)=> localStorage.setItem('session', JSON.stringify({email, name: email.split('@')[0]}));
  const signOut = ()=> localStorage.removeItem('session');

  // routing / view rendering
  const render = (name)=>{
    // show login if not signed
    if(!isSigned() && name !== 'login'){
      name = 'login';
    }
    view.innerHTML = '';
    let node = templates['tpl-'+name].content.cloneNode(true);
    view.appendChild(node);
    // init view
    if(name === 'login') initLogin();
    if(name === 'dashboard') initDashboard();
    if(name === 'books') initBooks();
    if(name === 'students') initStudents();
    if(name === 'attendance') initAttendance();
    if(name === 'reports') initReports();
  };

  // attach topnav
  qsa('#topnav button').forEach(btn=>{
    btn.addEventListener('click', ()=> render(btn.dataset.view));
  });
  qs('#logoutBtn').addEventListener('click', ()=> {
    signOut();
    render('login');
  });

  // Login
  function initLogin(){
    const form = qs('#loginForm');
    const session = JSON.parse(localStorage.getItem('session')||'null');
    if(session){ render('dashboard'); return; }
    form.addEventListener('submit', e=>{
      e.preventDefault();
      const email = qs('#email').value.trim();
      const pwd = qs('#password').value;
      if(!email) return alert('Email required');
      signIn(email);
      render('dashboard');
    });
  }

  // Dashboard
  function initDashboard(){
    const books = load('books'), students = load('students'), issues = load('issues');
    qs('#countBooks').textContent = books.length;
    qs('#countStudents').textContent = students.length;
    qs('#countIssued').textContent = issues.filter(i=> !i.return_date).length;
    const recent = qs('#recentIssues');
    recent.innerHTML = issues.slice(-5).reverse().map(i=>{
      const b = books.find(x=>x.id===i.book_id) || {title:'Unknown'};
      const s = students.find(x=>x.id===i.student_id) || {name:'Unknown'};
      return `<div class="card small"><strong>${b.title}</strong><div>${s.name} • Due: ${i.due_date} ${i.return_date?'<span class="badge">Returned</span>':''}</div></div>`;
    }).join('') || '<p>No recent issues.</p>';
  }

  // Books
  function initBooks(){
    const btnAdd = qs('#btnAddBook');
    const wrap = qs('#bookFormWrap');
    const form = qs('#bookForm');
    const tblBody = qs('#booksTable tbody');

    function refresh(){
      const books = load('books');
      tblBody.innerHTML = books.map((b,idx)=>`
        <tr>
          <td>${idx+1}</td>
          <td>${escapeHtml(b.title)}</td>
          <td>${escapeHtml(b.author||'')}</td>
          <td>${escapeHtml(b.isbn||'')}</td>
          <td>${b.copies}</td>
          <td>${b.available}</td>
          <td class="actions">
            <button data-id="${b.id}" class="edit">Edit</button>
            <button data-id="${b.id}" class="del">Delete</button>
            <button data-id="${b.id}" class="issue">Issue</button>
          </td>
        </tr>`).join('');
      // attach actions
      qsa('#booksTable .edit').forEach(b=> b.addEventListener('click', e=>{
        const id = e.target.dataset.id; editBook(id);
      }));
      qsa('#booksTable .del').forEach(b=> b.addEventListener('click', e=>{
        const id = e.target.dataset.id; if(confirm('Delete book?')){ deleteBook(id); }
      }));
      qsa('#booksTable .issue').forEach(b=> b.addEventListener('click', e=>{
        const id = e.target.dataset.id; issueBookUI(id);
      }));
    }

    function editBook(id){
      const books = load('books');
      const book = books.find(b=>b.id===id);
      if(!book) return alert('Not found');
      wrap.classList.remove('hidden');
      qs('#bookFormTitle').textContent = 'Edit Book';
      form.id.value = book.id;
      form.title.value = book.title;
      form.author.value = book.author;
      form.isbn.value = book.isbn;
      form.copies.value = book.copies;
    }

    function deleteBook(id){
      let books = load('books');
      books = books.filter(b=>b.id!==id);
      save('books', books);
      refresh();
    }

    function issueBookUI(bookId){
      // simple prompt to choose student and due date
      const students = load('students');
      if(students.length===0) return alert('Add students first');
      const s = students[0];
      const studentRolls = students.map(st=> `${st.roll} - ${st.name}`).join('\n');
      const selection = prompt('Choose student by number:\n' + students.map((st,i)=>`${i+1}. ${st.roll} - ${st.name}`).join('\n'));
      const idx = parseInt(selection)-1;
      if(isNaN(idx) || !students[idx]) return;
      const due = prompt('Enter due date (YYYY-MM-DD)', new Date(Date.now()+7*24*3600*1000).toISOString().slice(0,10));
      if(!due) return;
      const issues = load('issues');
      issues.push({id: uid(), book_id: bookId, student_id: students[idx].id, issue_date: new Date().toISOString().slice(0,10), due_date: due, return_date:null});
      save('issues', issues);
      // decrement available
      const books = load('books');
      const b = books.find(x=>x.id===bookId);
      if(b) b.available = Math.max(0, b.available-1);
      save('books', books);
      alert('Book issued');
      refresh();
    }

    form.addEventListener('submit', e=>{
      e.preventDefault();
      const id = form.id.value;
      let books = load('books');
      if(id){
        // update
        const book = books.find(b=>b.id===id);
        book.title = form.title.value;
        book.author = form.author.value;
        book.isbn = form.isbn.value;
        const newCopies = Math.max(1, parseInt(form.copies.value));
        // adjust available relative to copies change
        const diff = newCopies - book.copies;
        book.copies = newCopies;
        book.available = Math.max(0, book.available + diff);
      } else {
        books.push({id: uid(), title: form.title.value, author: form.author.value, isbn: form.isbn.value, copies: Math.max(1,parseInt(form.copies.value)||1), available: Math.max(1,parseInt(form.copies.value)||1)});
      }
      save('books', books);
      form.reset();
      wrap.classList.add('hidden');
      refresh();
    });

    qs('#cancelBook').addEventListener('click', ()=>{ form.reset(); wrap.classList.add('hidden'); });

    btnAdd.addEventListener('click', ()=>{ wrap.classList.remove('hidden'); qs('#bookFormTitle').textContent='Add Book'; form.id.value=''; form.reset(); });

    refresh();
  }

  // Students
  function initStudents(){
    const btnAdd = qs('#btnAddStudent');
    const wrap = qs('#studentFormWrap');
    const form = qs('#studentForm');
    const tblBody = qs('#studentsTable tbody');

    function refresh(){
      const students = load('students');
      tblBody.innerHTML = students.map((s,idx)=>`
        <tr>
          <td>${idx+1}</td>
          <td>${escapeHtml(s.roll)}</td>
          <td>${escapeHtml(s.name)}</td>
          <td>${escapeHtml(s.class||'')}</td>
          <td>${escapeHtml(s.phone||'')}</td>
          <td class="actions">
            <button data-id="${s.id}" class="edit">Edit</button>
            <button data-id="${s.id}" class="del">Delete</button>
          </td>
        </tr>
      `).join('');
      qsa('#studentsTable .edit').forEach(b=> b.addEventListener('click', e=>{
        const id = e.target.dataset.id; editStudent(id);
      }));
      qsa('#studentsTable .del').forEach(b=> b.addEventListener('click', e=>{
        const id = e.target.dataset.id; if(confirm('Delete student?')){ deleteStudent(id); }
      }));
    }

    function editStudent(id){
      const students = load('students');
      const s = students.find(x=>x.id===id);
      if(!s) return;
      wrap.classList.remove('hidden');
      form.id.value = s.id;
      form.roll.value = s.roll;
      form.name.value = s.name;
      form.class.value = s.class;
      form.phone.value = s.phone;
    }

    function deleteStudent(id){
      let students = load('students');
      students = students.filter(s=>s.id!==id);
      save('students', students);
      refresh();
    }

    form.addEventListener('submit', e=>{
      e.preventDefault();
      const id = form.id.value;
      let students = load('students');
      if(id){
        const s = students.find(x=>x.id===id);
        s.roll = form.roll.value; s.name = form.name.value; s.class = form.class.value; s.phone = form.phone.value;
      } else {
        students.push({id: uid(), roll: form.roll.value, name: form.name.value, class: form.class.value, phone: form.phone.value});
      }
      save('students', students);
      form.reset(); wrap.classList.add('hidden'); refresh();
    });

    qs('#cancelStudent').addEventListener('click', ()=>{ form.reset(); wrap.classList.add('hidden'); });
    btnAdd.addEventListener('click', ()=>{ wrap.classList.remove('hidden'); form.id.value=''; form.reset(); });

    refresh();
  }

  // Attendance
  function initAttendance(){
    const dateInput = qs('#attDate');
    const tbody = qs('#attTable tbody');
    dateInput.value = dateInput.value || new Date().toISOString().slice(0,10);
    function loadForDate(d){
      const students = load('students');
      const attendance = load('attendance');
      tbody.innerHTML = students.map(s=>{
        const rec = attendance.find(a=>a.student_id===s.id && a.date===d);
        const status = rec? rec.status : 'absent';
        return `<tr>
          <td>${escapeHtml(s.roll)}</td>
          <td>${escapeHtml(s.name)}</td>
          <td>
            <select data-id="${s.id}">
              <option value="present" ${status==='present'?'selected':''}>Present</option>
              <option value="absent" ${status==='absent'?'selected':''}>Absent</option>
            </select>
          </td>
        </tr>`;
      }).join('');
    }
    loadForDate(dateInput.value);
    dateInput.addEventListener('change', ()=> loadForDate(dateInput.value));

    qs('#attendanceForm').addEventListener('submit', e=>{
      e.preventDefault();
      const d = dateInput.value;
      const selects = Array.from(qsa('#attTable select'));
      let attendance = load('attendance');
      selects.forEach(s=> {
        const student_id = s.dataset.id;
        const status = s.value;
        const idx = attendance.findIndex(a=>a.student_id===student_id && a.date===d);
        if(idx>=0) attendance[idx].status = status;
        else attendance.push({id: uid(), student_id, date: d, status});
      });
      save('attendance', attendance);
      alert('Attendance saved for '+d);
    });
  }

  // Reports
  function initReports(){
    const overdueWrap = qs('#overdueList');
    const attBody = qs('#attSummary tbody');
    const books = load('books'), students = load('students'), issues = load('issues'), attendance = load('attendance');
    const today = new Date().toISOString().slice(0,10);
    const overdue = issues.filter(i=> !i.return_date && i.due_date < today);
    overdueWrap.innerHTML = overdue.length ? overdue.map(o=>{
      const b = books.find(x=>x.id===o.book_id) || {};
      const s = students.find(x=>x.id===o.student_id) || {};
      return `<div class="card small"><strong>${escapeHtml(b.title||'')}</strong><div>${escapeHtml(s.name||'')} • Due ${o.due_date}</div></div>`;
    }).join('') : '<p>No overdue books</p>';

    // attendance summary
    attBody.innerHTML = students.map(s=>{
      const recs = attendance.filter(a=> a.student_id===s.id);
      const presents = recs.filter(r=> r.status==='present').length;
      const total = recs.length;
      const percent = total ? Math.round((presents/total)*100) : 0;
      return `<tr><td>${escapeHtml(s.roll)}</td><td>${escapeHtml(s.name)}</td><td>${presents}</td><td>${total}</td><td>${percent}%</td></tr>`;
    }).join('');
  }

  // helper functions
  function escapeHtml(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  // initial view
  render(isSigned() ? 'dashboard' : 'login');

  // expose for debugging
  window.LAS = {
    load, save, uid
  };

})();
